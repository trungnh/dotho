
<?php
echo uncodeHTML($objmodule->HTML);
?>
