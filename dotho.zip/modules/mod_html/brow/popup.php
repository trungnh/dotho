<div id="popup">
    <div style="z-index: 799999; border: medium none; margin: 0pt; padding: 0pt; width: 100%; height: 100%; top: 0pt; left: 0pt; opacity: 0.75; position: fixed; background-color: rgb(0, 0, 0);" class="block_close" title="Nh?n chu?t d? d�ng"></div>
    <div style="z-index: 800010; position: fixed; padding: 1px; margin: 0px; width: 100%; top: 80px; text-align: center; color: rgb(0, 0, 0);" class="blockUI blockMsg blockPage">
<?php
echo uncodeHTML($objmodule->HTML);
?>
</div>
</div>
