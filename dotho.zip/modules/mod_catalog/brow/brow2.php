<?php
$objevent=new CLS_EVENT();
echo $objevent->listMenuTopEvent(" and `ismenu`='1'");
?>