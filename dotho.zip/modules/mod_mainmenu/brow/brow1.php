<?php
$objmenuitem=new CLS_MENUITEM;
echo $objmenuitem->ListMenuItem($objmodule->MnuID,0,0,0)
?>