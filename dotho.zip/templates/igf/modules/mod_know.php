<a href="#" class="know_heading"><h2>Kiến thức hệ thống</h2></a>
<div class="know">
    <h3>Cloud Automatic</h3>
    <ul>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
    </ul>
</div>
<div class="know">
    <h3>Cloud Automatic</h3>
    <ul>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
    </ul>
</div>
<div class="know">
    <h3>Cloud Automatic</h3>
    <ul>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
    </ul>
</div>
<div class="know">
    <h3>Cloud Automatic</h3>
    <ul>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
        <li><a href="#">Cloud server</a></li>
    </ul>
</div>