<div class="news">
  <a href="#" class="news_heading"> 
  	<div class="news_imgtit"><img src="images/news/news_rack.gif"/></div> 
    <h2>Cho thuê Rack</h2>
  </a>
  <div class="news_content">Không giống như các công ty khác sử dụng các máy chủ rẻ tiền hay máy chủ 1 CPU, VinaHost sử dụng hệ thống máy chủ Supermicro cao cấp với 2 CPU Intel Xeon quad-core
  </div>
  <a href="" class="news_btndetail"><small>>></small> Chi tiết <small><<</small></a>
</div>
<div class="news">
  <a href="#" class="news_heading"> 
  	<div class="news_imgtit"><img src="images/news/news_server.gif"/></div> 
    <h2>Cho thuê máy chủ</h2>
  </a>
  <div class="news_content">Không giống như các công ty khác sử dụng các máy chủ rẻ tiền hay máy chủ 1 CPU, VinaHost sử dụng hệ thống máy chủ Supermicro cao cấp với 2 CPU Intel Xeon quad-core
  </div>
  <a href="" class="news_btndetail"><small>>></small> Chi tiết <small><<</small></a>
</div>
<div class="news">
  <a href="#" class="news_heading"> 
  	<div class="news_imgtit"><img src="images/news/news_3.gif"/></div>
    <h2>Cho thuê chỗ đặt máy chủ</h2>
  </a>
  <div class="news_content">Không giống như các công ty khác sử dụng các máy chủ rẻ tiền hay máy chủ 1 CPU, VinaHost sử dụng hệ thống máy chủ Supermicro cao cấp với 2 CPU Intel Xeon quad-core
  </div>
  <a href="" class="news_btndetail"><small>>></small> Chi tiết <small><<</small></a>
</div>
<div class="news news_end">
  <a href="#" class="news_heading"> 
  	<div class="news_imgtit"><img src="images/news/news_4.gif"/></div> 
    <h2>Cho thuê không gian DC</h2>
  </a>
  <div class="news_content">Không giống như các công ty khác sử dụng các máy chủ rẻ tiền hay máy chủ 1 CPU, VinaHost sử dụng hệ thống máy chủ Supermicro cao cấp với 2 CPU Intel Xeon quad-core
  </div>
  <a href="" class="news_btndetail"><small>>></small> Chi tiết <small><<</small></a>
</div>