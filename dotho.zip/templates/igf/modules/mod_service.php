<div id="service_box">
    <div class="service">
    	<div class="serpad">
        	<h1>CORE 2 DUO</h1>
        	<div class="serconent">feawf gfvdwg dư gdw g g ewdg ew ge qwg e ư ge wg e qwgt e q gew g e</div>
    		<div class="serprice">$80/mo</div>
    	</div>
    </div>
    <div class="service">
    	<div class="serpad">
        	<h1>GREAT DEAL</h1>
        	<div class="serconent">gewgt ergewr g ew gẻ g rew g wgfv etntr h e r 32  g reg4y r3 bf e g e g 3 rư tg 43r y5r3 4y gh </div>
            <div class="serprice">$80/mo</div>
    	</div>
    </div>
    <div class="service service_vip">
    	<div class="serpad">
        	<h1>GREAT DEAL</h1>
            <div class="serconent">gewgt ergewr g ew gẻ g rew g wgfv etntr h e r 32  g reg4y r3 bf e g e g 3 rư tg 43r y5r3 4y gh</div> 
    		<div class="serprice">$80/mo</div>
        </div>
    </div>
    <div class="service">
    	<div class="serpad">
        	&nbsp;
        </div> 
    </div>
    <div class="service">
    	<div class="serpad">
        	<h1>GREAT DEAL</h1>
            <div class="serconent">gewgt ergewr g ew gẻ g rew g wgfv etntr h e r 32  g reg4y r3 bf e g e g 3 rư tg 43r y5r3 4y gh</div>
    		<div class="serprice">$80/mo</div>
        </div> 
    </div>
    <div class="service">
    	<div class="serpad">
        	<h1>GREAT DEAL</h1>
            <div class="serconent">gewgt ergewr g ew gẻ g rew g wgfv etntr h e r 32  g reg4y r3 bf e g e g 3 rư tg 43r y5r3 4y gh </div>
    		<div class="serprice">$80/mo</div>
        </div>
    </div>
</div>