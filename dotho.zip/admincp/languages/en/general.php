<?php
// Chung
define("SEARCH","Search");
define("TYPE","Type");
define("MENUS","Menus");
define("MENU_ASSIGNMENT","Menu Assignment");
define("ALL","All");
define("NONE","None");
define("SELECT_MENUS","Select Menu Item(s)");
define("SHOWTITLE","Show Title");

define("IS_DEFAULT","Default");
define("ACTIVE","Active");
define("ADD","Add New");
define("EDIT","Edit");
define("DELETE","Delete");
/*------------------USER-------------------------*/
define("LANG_USERNAME","Username");
define("LANG_GENDER","Gender");
define("ACCOUNT","Infor Account");
define("LANG_EMAIL","Email");
define("LANG_GUSER","Guser");
define("LANG_NAME","Name");
define("LANG_PASSWORD","Password");
define("LANG_REPASSWORD","Re-Password");
define("LANG_PASSWORDOLD","Password-old");
define("LANG_REPASSWORDOLD","Re-Password-old");
define("LANG_PASSWORDNEW","Password-new");
define("LANG_REPASSWORDNEW","Re-Password-new");
define("CFIRSTNAME","Firstname");
define("CBIRTHDAY","Birthday");
define("CLASTTNAME","Lastname");
define("CADDRESS","Address");
define("LANG_PHONE","Phone");
define("LANG_MOBILE","Mobile");
/*-----------CONTENT---------*/
define("TITLE","Title");
define("CTITLE","Title");
define("CCODE","Code");
define("CNAME","Name");
define("CCONTENT","Content");
define("CINTRO","Intro");
define("CFULLTEXT","Fulltext");
define("CCREATDATE","Creatdate");
define("CMODIFY","Modifydate");
define("CAUTHOR","Author");
define("CMETAKEY","MetaKey");
define("CMETADESC","MetaDesc");
define("CVISITED","Visited");
define("CEXPAND","Expand");

define("CMEM","Group Member");
define("CDESC","Description");
define("CDETAIL","Detail");
define("CDEFAULT","isDefault");
define("CTHEME","Theme");
define("CCATEGORY","Category");
define("CARTICLE","Article");

define("CDATETIME","Datetime");
define("CDATE","Date");
define("CID","Id");
define("CPAR_ID","Par");
define("CTYPE","View Type");
define("CORDER","Order");
define("CPOSITION","Position");
define("CACTIVE","Active");
define("CEDIT","Edit");
define("CDELETE","Delete");
define("CPUBLIC","Publish");
define("CUNPUBLIC","Unpublish");
define("CYES","Yes");
define("CNO","No");
define("CSITE","Site");
define("CADMIN","Admin");
define("CLINK","Link");
define("CPARENT","Parent");
define("CCLASS","Class");
/*-----------MENU ACTION---------*/
define("MACTIVE","Active");
define("MPUBLISH","Publish&nbsp;");
define("MUNPUBLISH","UnPublish");
define("MADDNEW","Add New");
define("MEDIT","&nbsp;&nbsp;Edit&nbsp;&nbsp;");
define("MUPDATE","Update");
define("MDELETE","Delete");
define("MMOVE","Move");
define("MCLOSE","Close");
define("MSAVE","Save");
define("MALL","All");
/*--------------PAGING---------*/
define("FIRST","First");
define("PREVIEW","Preview");
define("NEXT","Next");
define("END","End");

/*---MENU---*/
define("MSYSTEM","System");
define("MSITE","Site");
define("MCONTROL_PANEL","Control Panel");
define("MUSERS","Users Manager");
define("MUSER","User Manager");
define("MMEDIA","Media Manager");
define("MCONFIG","Config Site");
define("MLOGOUT","Logout");

define("MFRONT_END","Front End");
define("MBACK_END","Back End");

define("MMENU","Menus");
define("MMENU_MANAGER","Menus Manager");
define("MMENUITEM","MenuItem Manager");
define("MCONTENT","Contents");
define("MCATEGORY","Category Manager");
define("MARTICLE","Article Manager");
define("MFRONT_PAGE","Front Page Manager");

define("MCOMPONENT","Components");
define("MMEMBER_GROUP","Members Group");
define("MMEMBER","Member Manager");
define("MCONTACT","Contact Manager");
define("MSUPPORT","Support Manager");

define("MEXTENSION","Extensions");
define("MINSTALL","Install/Uninstall");
define("MMODULES","Module Manager");
define("MTEMPLATE","Template Manager");
define("MLANGUAGE","Language Manager");

define("MHELP","Help");
define("MABOUT","About GF-CMS");
define("MVERSTION","GF-CMS Version 1.0");

define("ISN'T EXIST","isn't exist");

define("CONFIRM_DELETE","Do you want to delete this record?");
define("SELECT_ONCE_CATEGORY","Select once category");
define("SELECT_ONCE_ARTICLE","Select once article");
/****************************************************/
define("CF_DELETE01","Are you sure to delete?");
?>