<form method="post" action="components/com_check_ip/check_ip.php">
    <fieldset>
        <legend>Đăng nhập</legend>
        <table>
            <tr>
                <td width="200px" align="right">Tên đăng nhập : &nbsp;</td>
                <td><input type="text" size="30" name="username" /></td>
            </tr>
            <tr>
                <td width="200px" align="right">Mật khẩu : &nbsp;</td>
                <td><input type="password" size="30" name="password" /></td>
            </tr>
            <tr>
                <td  align="center" colspan="2"><input type="submit" value="Đăng nhập" />&nbsp; <input type="reset" value="Nhập lại" /></td>
            </tr>
        </table>
    </fieldset>
</form>
